<html>
      <head>
	       <title>ma page</title>
		   <meta charset="utf-8" />
	  </head>
      <body>
	        <center>
	        <form action = "text2.php" method = "POST">
			<label for = "user">USER</label>
			<input type = "text" name = "user"></input>
			</br>
			<label for = "password">PASSWORD</label>
			<input type = "password" name = "password"></input>
			</br>
			<label for = "email">ADRESSE EMAIL</label>
			<input type = "email" name = "email"></input>
			</br>
			<input type = "submit" action = "envoyez"/>
			</br>
			<p>Pour vous inscrire, veillez clicker <a href = "inscription.php">ici</a></p>
			 </center>
			</form>
	  
	  </body>



</html>